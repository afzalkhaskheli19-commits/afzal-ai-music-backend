import os
import uuid
from pathlib import Path

import scipy.io.wavfile
import torch
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from transformers import AutoProcessor, MusicgenForConditionalGeneration

APP_DIR = Path(__file__).parent
OUT_DIR = APP_DIR / "outputs"
OUT_DIR.mkdir(exist_ok=True)

app = FastAPI(title="Afzal AI Music Backend")

MODEL_NAME = os.getenv("MUSIC_MODEL", "facebook/musicgen-small")
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

processor = None
model = None

class GenerateRequest(BaseModel):
    lyrics: str = ""
    language: str = "Sindhi"
    vocal_style: str = "Male Sufi"
    music_style: str = "Sindhi Sufi Folk, slow emotional"
    duration_seconds: int = 8

@app.get("/")
def home():
    return {"status": "Afzal AI Music backend is running", "device": DEVICE}

def load_model():
    global processor, model
    if processor is None or model is None:
        processor = AutoProcessor.from_pretrained(MODEL_NAME)
        model = MusicgenForConditionalGeneration.from_pretrained(MODEL_NAME)
        model.to(DEVICE)

@app.post("/generate")
def generate(req: GenerateRequest):
    if not req.music_style.strip():
        raise HTTPException(400, "Music style is required")

    # MusicGen generates instrumental music from text; it does not sing supplied lyrics.
    prompt = (
        f"{req.music_style}. "
        f"Traditional {req.language} musical character, "
        f"{req.vocal_style} mood and expressive arrangement."
    )

    try:
        load_model()
        seconds = max(5, min(int(req.duration_seconds), 30))
        # MusicGen's documented generation limit is about 30 seconds.
        tokens_per_second = 50
        max_new_tokens = seconds * tokens_per_second

        inputs = processor(text=[prompt], padding=True, return_tensors="pt").to(DEVICE)

        with torch.no_grad():
            audio_values = model.generate(
                **inputs,
                do_sample=True,
                guidance_scale=3,
                max_new_tokens=max_new_tokens,
            )

        audio = audio_values[0, 0].detach().cpu().numpy()
        sample_rate = model.config.audio_encoder.sampling_rate

        filename = f"{uuid.uuid4().hex}.wav"
        output_path = OUT_DIR / filename
        scipy.io.wavfile.write(output_path, rate=sample_rate, data=audio)

        return {
            "ok": True,
            "file": f"/audio/{filename}",
            "message": "Instrumental music generated successfully."
        }
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/audio/{filename}")
def audio(filename: str):
    path = OUT_DIR / Path(filename).name
    if not path.exists():
        raise HTTPException(404, "Audio not found")
    return FileResponse(path, media_type="audio/wav", filename=path.name)
