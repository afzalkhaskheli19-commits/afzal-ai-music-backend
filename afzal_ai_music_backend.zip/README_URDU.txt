AFZAL AI MUSIC BACKEND

Ye backend open MusicGen model ko local/server GPU par chalata hai.
Important: MusicGen text se instrumental music banata hai; ye supplied lyrics ko gaata nahi.
Isliye baad mein singing/vocal model alag connect karna hoga.

START:
1. Python 3.10/3.11 environment banao.
2. pip install -r requirements.txt
3. uvicorn app:app --host 0.0.0.0 --port 8000

API:
POST /generate

Example JSON:
{
  "lyrics": "tumhari lyrics",
  "language": "Sindhi",
  "vocal_style": "Male Sufi",
  "music_style": "Sindhi Sufi Folk, slow emotional",
  "duration_seconds": 8
}

GET /audio/FILENAME.wav

Production mein GPU server zaroori hai; CPU par generation bohat slow ho sakti hai.
